using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using SimpleApiReseller.Models;
using ApiResellerSystem.Data;
using ApiResellerSystem.Models;

// Ensure correct minimal hosting setup for .NET 8
var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllersWithViews();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Database
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("DefaultConnection"))
    ));

// JWT Authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["JWT:Issuer"],
            ValidAudience = builder.Configuration["JWT:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:Secret"]!))
        };
    });

builder.Services.AddAuthorization();

// HttpClient for API forwarding
builder.Services.AddHttpClient();

// CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp", policy =>
    {
        policy.WithOrigins("http://localhost:3000") // React app URL
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

var app = builder.Build();

// Static files FIRST - before everything else
app.UseDefaultFiles();
app.UseStaticFiles();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseCors("AllowReactApp");
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapControllers();

// Initialize database and seed data
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    // Ensure database is created
    context.Database.EnsureCreated();

    // Seed initial data
    await SeedInitialData(context, app.Environment.IsDevelopment());
}

app.Run();

// Seed initial data method
static async Task SeedInitialData(ApplicationDbContext context, bool isDevelopment)
{
    try
    {
        // Check if admin user exists
        if (!await context.Users.AnyAsync(u => u.Role == UserRole.Admin))
        {
            // Create default admin user
            var adminUser = new User
            {
                Username = "admin",
                Email = "admin@example.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"), // Change this password!
                Role = UserRole.Admin,
                IsActive = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Users.Add(adminUser);
            await context.SaveChangesAsync();

            Console.WriteLine("Default admin user created:");
            Console.WriteLine("Username: admin");
            Console.WriteLine("Password: admin123");
            Console.WriteLine("IMPORTANT: Change the admin password after first login!");
        }

        // Check if system settings exist
        if (!await context.SystemSettings.AnyAsync(s => s.SettingKey == "REQUEST_COST"))
        {
            var requestCostSetting = new SystemSettings
            {
                SettingKey = "REQUEST_COST",
                SettingValue = "0.01", // Default: 1 cent per request
                UpdatedAt = DateTime.UtcNow
            };

            context.SystemSettings.Add(requestCostSetting);
            await context.SaveChangesAsync();

            Console.WriteLine("Default system settings created:");
            Console.WriteLine("Request Cost: $0.01 per request");
        }

        // Optional: Create a demo client for testing
        if (isDevelopment && !await context.Clients.AnyAsync())
        {
            var demoUser = new User
            {
                Username = "democlient",
                Email = "demo@client.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("demo123"),
                Role = UserRole.Client,
                IsActive = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Users.Add(demoUser);
            await context.SaveChangesAsync();

            var demoClient = new Client
            {
                UserId = demoUser.Id,
                CompanyName = "Demo Company",
                ContactPerson = "Demo User",
                Phone = "555-0123",
                Address = "123 Demo Street",
                ApiKey = "ak_demo123456789",
                ApiSecret = "as_demo987654321",
                CreditBalance = 10.00m, // $10 initial balance
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Clients.Add(demoClient);
            await context.SaveChangesAsync();

            // Log initial credit
            var initialCredit = new ClientCredit
            {
                ClientId = demoClient.Id,
                Amount = 10.00m,
                TransactionType = "Recharge",
                Description = "Initial demo credit",
                CreatedAt = DateTime.UtcNow
            };

            context.ClientCredits.Add(initialCredit);
            await context.SaveChangesAsync();

            Console.WriteLine("Demo client created for development:");
            Console.WriteLine("Username: democlient");
            Console.WriteLine("Password: demo123");
            Console.WriteLine("API Key: ak_demo123456789");
            Console.WriteLine("Initial Balance: $10.00");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error seeding initial data: {ex.Message}");
    }
}

//http://localhost:5291/swagger/index.html