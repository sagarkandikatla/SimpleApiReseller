// ...existing code...
// Register controller with the correct module name
angular.module('apiResellerApp')
  .controller('LoginController', ['$scope', function($scope) {
    // Controller logic here
  }]);
// ...existing code...
