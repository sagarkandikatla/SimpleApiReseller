﻿// AngularJS App Configuration
angular.module('apiResellerApp', ['ngRoute'])
    .config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        $routeProvider
            .when('/login', {
                templateUrl: 'views/login.html?vc=0.0.1',
                controller: 'LoginController'
            })
            .when('/admin/dashboard', {
                templateUrl: 'views/admin/dashboard.html?vc=0.0.1',
                controller: 'AdminDashboardController',
                requireAuth: true,
                requireRole: 'Admin'
            })
            .when('/admin/clients', {
                templateUrl: 'views/admin/clients.html?vc=0.0.1',
                controller: 'AdminClientsController',
                requireAuth: true,
                requireRole: 'Admin'
            })
            .when('/admin/settings', {
                templateUrl: 'views/admin/settings.html?vc=0.0.1',
                controller: 'AdminSettingsController',
                requireAuth: true,
                requireRole: 'Admin'
            })
            .when('/client/dashboard', {
                templateUrl: 'views/client/dashboard.html?vc=0.0.1',
                controller: 'ClientDashboardController',
                requireAuth: true,
                requireRole: 'Client'
            })
            .when('/client/credits', {
                templateUrl: 'views/client/credits.html?vc=0.0.1',
                controller: 'ClientCreditsController',
                requireAuth: true,
                requireRole: 'Client'
            })
            .when('/client/statistics', {
                templateUrl: 'views/client/statistics.html?vc=0.0.1',
                controller: 'ClientStatisticsController',
                requireAuth: true,
                requireRole: 'Client'
            })
            .when('/documentation', {
                templateUrl: 'views/documentation.html?vc=0.0.1',
                controller: 'DocumentationController',
                requireAuth: true
            })
            .when('/', {
                redirectTo: function (params, path, search) {
                    var authService = angular.injector(['apiResellerApp']).get('AuthService');
                    var user = authService.getCurrentUser();
                    if (user) {
                        return user.role === 'Admin' ? '/admin/dashboard' : '/client/dashboard';
                    }
                    return '/login';
                }
            })
            .otherwise({
                redirectTo: '/'
            });
    }])
    .run(['$rootScope', '$location', 'AuthService', function ($rootScope, $location, AuthService) {
        // Global variables
        $rootScope.loading = false;
        $rootScope.alert = {};

        // Show alert helper
        $rootScope.showAlert = function (message, type = 'info') {
            $rootScope.alert = { message: message, type: type };
        };

        // Clear alert helper
        $rootScope.clearAlert = function () {
            $rootScope.alert = {};
        };

        // Route change start
        $rootScope.$on('$routeChangeStart', function (event, next, current) {
            $rootScope.loading = true;
            $rootScope.clearAlert();

            // Check authentication
            if (next.requireAuth && !AuthService.isAuthenticated()) {
                event.preventDefault();
                $location.path('/login');
                return;
            }

            // Check role authorization
            if (next.requireRole) {
                var user = AuthService.getCurrentUser();
                if (!user || user.role !== next.requireRole) {
                    event.preventDefault();
                    $rootScope.showAlert('Access denied. Insufficient permissions.', 'danger');
                    $location.path('/');
                    return;
                }
            }
        });

        // Route change success
        $rootScope.$on('$routeChangeSuccess', function () {
            $rootScope.loading = false;
        });

        // Route change error
        $rootScope.$on('$routeChangeError', function () {
            $rootScope.loading = false;
            $rootScope.showAlert('Failed to load page', 'danger');
        });

        // HTTP errors
        $rootScope.$on('httpError', function (event, error) {
            $rootScope.loading = false;
            if (error.status === 401) {
                AuthService.logout();
                $location.path('/login');
            } else {
                $rootScope.showAlert(error.message || 'An error occurred', 'danger');
            }
        });
    }]);

// Ensure the AngularJS app module name matches index.html
var app = angular.module('apiResellerApp', ['ngRoute']);

// Global filters
angular.module('apiResellerApp')
    .filter('currency', function () {
        return function (amount) {
            if (amount === null || amount === undefined) return '$0.00';
            return '$' + parseFloat(amount).toFixed(2);
        };
    })
    .filter('dateFormat', function () {
        return function (dateString) {
            if (!dateString) return '';
            return new Date(dateString).toLocaleDateString();
        };
    })
    .filter('dateTimeFormat', function () {
        return function (dateString) {
            if (!dateString) return '';
            return new Date(dateString).toLocaleString();
        };
    });